# Class Management Android App

This project wraps the supplied Class Management HTML app in a native Android WebView.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync/download the Android Gradle Plugin and SDK if prompted.
3. Build > Build App Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on the tablet.

The HTML app is bundled locally at `app/src/main/assets/index.html`.
The app has Internet permission because the HTML app connects to Supabase over HTTPS.
