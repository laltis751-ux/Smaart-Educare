# Smaart Educare — Final Android Project

This build includes Supabase Auth login for Admin, Teacher and Student and restores the existing Supabase session when the Android WebView/app is reopened. Closing, minimizing, or reopening the app does not sign the user out. Only the in-app Logout button signs out.

App version: 1.7
