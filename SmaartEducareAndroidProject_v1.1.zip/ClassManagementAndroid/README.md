# Smaart Educare Android App

Dedicated Android wrapper for the Class Management app.

- App name: Smaart Educare
- Launcher icon: Smaart Educare logo (emblem/book)
- Version: 1.1
- Supabase/HTML app remains bundled in `app/src/main/assets/index.html`.
